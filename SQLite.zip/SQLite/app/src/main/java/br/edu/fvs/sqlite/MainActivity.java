package br.edu.fvs.sqlite;

import android.database.Cursor;
import android.database.CursorIndexOutOfBoundsException;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {

            SQLiteDatabase banco = openOrCreateDatabase("sistema", MODE_PRIVATE, null);
            // CRIAR TABELA
            banco.execSQL("CREATE TABLE IF NOT EXISTS usuario(id INTEGER PRIMARY KEY AUTOINCREMENT, usuario VARCHAR(50), senha INT(8))");

            //INSERÇÃO DE DADOS
            banco.execSQL("INSERT INTO usuario(usuario, senha) VALUES ('Hugo Silva', 1999)");
            banco.execSQL("INSERT INTO usuario(usuario, senha) VALUES ('Cherno_Alpha', 1988)");
            banco.execSQL("INSERT INTO usuario(usuario, senha) VALUES ('Darkness', 1999)");

            //ALTERAR DADOS
            banco.execSQL("UPDATE usuario SET usuario='NomeALterado' WHERE id = 1");

            //EXCLUIR DADOS
            banco.execSQL("DELETE FROM usuario WHERE id = 2");

            // Retornar e listar dados no banco
            Cursor cursor = banco.rawQuery("SELECT * FROM usuario WHERE usuario LIKE '%silv%'", null);

            //Captura o indice das colunas
            int indiceID = cursor.getColumnIndex("id");
            int indiceUsuario = cursor.getColumnIndex("usuario");
            int indiceSenha = cursor.getColumnIndex("senha");

            //Voltar para o primeiro item da lista
            cursor.moveToFirst();

            while (cursor != null){
                Log.i("DADOS USUARIOS - id", cursor.getString(indiceID));
                Log.i("DADOS USUARIOS -usuario", cursor.getString(indiceUsuario));
                Log.i("DADOS USUARIOS - senha", cursor.getString(indiceSenha));
                // Avançar para o próximo resultado
                cursor.moveToNext();
            }

        } catch (Exception e){
            e.printStackTrace();
        }
    }
}
