package com.example.natan.listview;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DescricaoEstado extends AppCompatActivity {

    TextView estadoNome;
    TextView estadoDescricao;

    String[] descricoes = {"é quente", "é frio", "tem queijo", "é longe"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_descricao_estado);

        estadoNome = findViewById(R.id.nome);
        estadoDescricao = findViewById(R.id.id_descricao);

        Intent intent = getIntent();

        String texto = intent.getStringExtra("estado");

        if (texto != null){
            estadoNome.setText(texto.toString());
            if (texto.equals("Ceara")){
                estadoDescricao.setText(descricoes[0]);
            } else if(texto.equals("São Paulo")){
                estadoDescricao.setText(descricoes[1]);
            } else if(texto.equals("Minas Gerais")){
                estadoDescricao.setText(descricoes[2]);
            } else if(texto.equals("Acre")){
                estadoDescricao.setText(descricoes[3]);
            }

        }


    }
}
