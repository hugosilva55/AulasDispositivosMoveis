package br.edu.fvs.crudsqlite;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import br.edu.fvs.crudsqlite.usuario.Usuario;
import br.edu.fvs.crudsqlite.usuario.UsuarioDAO;

public class TelaUsuario extends AppCompatActivity {

    Usuario usuario;
    Usuario usuarioCarregado;
    UsuarioDAO usuarioDAO;

    EditText cadNome;
    EditText cadUsuario;
    EditText cadSenha;

    Button btSalvar;
    Button btPesquisar;
    Button btExcluir;
    Button btSincronizar;
    Button btVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_usuario);

        cadNome = findViewById(R.id.cadNome);
        cadUsuario = findViewById(R.id.cadUsuario);
        cadSenha = findViewById(R.id.cadSenha);

        btSalvar = findViewById(R.id.btSalvar);
        btPesquisar = findViewById(R.id.btPesquisar);
        btExcluir = findViewById(R.id.btExcluir);
        btSincronizar = findViewById(R.id.btSincronizar);
        btVoltar = findViewById(R.id.btVoltar);


        usuario = new Usuario();
        usuarioCarregado = new Usuario();
        usuarioDAO = new UsuarioDAO(openOrCreateDatabase(usuarioDAO.NOME_BANCO, MODE_PRIVATE, null));

        btSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (usuarioCarregado != null){
                    if (usuarioCarregado.getId() != 0){
                        usuarioCarregado.setNome(cadNome.getText().toString());
                        usuarioCarregado.setLogin(cadUsuario.getText().toString());
                        usuarioCarregado.setSenha(cadSenha.getText().toString());
                        usuarioDAO.salvarUsuario(usuarioCarregado);
                    } else{
                        usuario.setNome(cadNome.getText().toString());
                        usuario.setLogin(cadUsuario.getText().toString());
                        usuario.setSenha(cadSenha.getText().toString());
                        usuarioDAO.salvarUsuario(usuarioCarregado);
                    }
                    Toast.makeText(getApplicationContext(), "Dados Salvos!", Toast.LENGTH_SHORT).show();
                    limparCampos();
                }

            }
        });

        btExcluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (usuarioCarregado.getId() != 0){
                    usuarioDAO.deletarUsuario(usuarioCarregado);
                    limparCampos();
                }
            }
        });

        btPesquisar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TelaUsuario.this, TelaPesquisarUsuario.class));
            }
        });

        carregarUsuario();

    }

    public void limparCampos(){
        cadNome.setText("");
        cadSenha.setText("");
        cadUsuario.setText("");

        usuario = new Usuario();
        usuarioCarregado = new Usuario();

    }

    public void carregarUsuario(){
        Intent i = getIntent();
        usuarioCarregado = (Usuario) i.getSerializableExtra("usuario");
        if (usuarioCarregado != null){
            cadNome.setText(usuarioCarregado.getNome());
            cadUsuario.setText(usuarioCarregado.getLogin());
            cadSenha.setText(usuarioCarregado.getSenha());

            btExcluir.setEnabled(true);
        } else{
            btExcluir.setEnabled(false);
        }
    }
}
