package br.edu.fvs.sharedpreferences;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText login;
    Button botaoEntrar;
    TextView usuario;
    static final String ARQUIVO_LOGIN = "ArquivoLogin";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login = findViewById(R.id.Login);
        botaoEntrar = findViewById(R.id.bt_Entrar);
        usuario = findViewById(R.id.Usuario);

        botaoEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SharedPreferences sharedPreferences = getSharedPreferences(ARQUIVO_LOGIN, 0);

                SharedPreferences.Editor editor = sharedPreferences.edit();

                if (login.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Digite seu Login", Toast.LENGTH_SHORT).show();
                } else{
                    editor.putString("login", login.getText().toString());
                    editor.commit();
                    usuario.setText(login.getText().toString());
                }
            }
        });

        SharedPreferences sharedPreferences = getSharedPreferences(ARQUIVO_LOGIN, 0);
        if (sharedPreferences.contains("login")){
            String login = sharedPreferences.getString("login", "Usuário não cadastrado!");
            usuario.setText(login);
            this.login.setText(login);
        }
    }
}
