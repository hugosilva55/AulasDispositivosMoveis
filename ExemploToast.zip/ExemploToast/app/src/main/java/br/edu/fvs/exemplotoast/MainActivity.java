package br.edu.fvs.exemplotoast;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button botao;
    EditText valorA;
    EditText valorB;
    EditText valorC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        botao = findViewById(R.id.btnAcao);
        valorA = findViewById(R.id.valorA);
        valorB = findViewById(R.id.valorB);
        valorC = findViewById(R.id.valorC);

        String A = valorA.getText().toString();
        final int varA = Integer.parseInt(A);

        String B = valorB.getText().toString();
        final int varB = Integer.parseInt(B);

        String C = valorC.getText().toString();
        final int varC = Integer.parseInt(C);

        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String resultado;

                if (varA == varB && varB == varC ){
                   resultado = "Triângulo Equilátero";
                } else if (varA == varB || varA == varC || varB == varC){
                    resultado = "Triângulo Isósceles";
                } else{
                    resultado = "Triângulo Escaleno";
                }

                Toast.makeText(getApplicationContext(),resultado, Toast.LENGTH_LONG).show();
            }
        });

    }
}
