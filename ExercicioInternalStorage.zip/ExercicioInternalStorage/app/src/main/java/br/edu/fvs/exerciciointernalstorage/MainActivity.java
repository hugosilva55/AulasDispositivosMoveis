package br.edu.fvs.exerciciointernalstorage;

import android.content.Context;
import android.icu.util.Output;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {

    EditText nome, email, senha;
    Button botao;
    final String ARQUIVO = "dadosUsuario.txt";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nome = findViewById(R.id.nome);
        email = findViewById(R.id.email);
        senha = findViewById(R.id.senha);
        botao = findViewById(R.id.botao);

        if (carregarDados() != null){
            nome.setText(carregarDados()[0]);
            nome.setText(carregarDados()[1]);
            nome.setText(carregarDados()[2]);
        }

        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nomeDigitado = nome.getText().toString();
                String emailDigitado = email.getText().toString();
                String senhaDigitada = senha.getText().toString();

                String textoFinal = nomeDigitado+";"+emailDigitado+";"+senhaDigitada;

                if (!textoFinal.isEmpty()){
                    salvarArquivo(textoFinal);
                    Toast.makeText(MainActivity.this, "Usuráio salvo com sucesso", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    public void salvarArquivo(String dados){
        try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(openFileOutput(ARQUIVO, Context.MODE_PRIVATE));

            outputStreamWriter.write(dados);
            outputStreamWriter.close();
        }catch (IOException e){
            Log.v("MainActivity", e.getMessage());
        }
    }

    public String[] carregarDados(){
        String[] dadosCarregados = null;

        try {
            InputStream arquivoCarregado = openFileInput(ARQUIVO);
            if (arquivoCarregado != null){
                InputStreamReader inputStreamReader = new InputStreamReader(arquivoCarregado);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                if (bufferedReader.readLine() != null){
                    dadosCarregados = bufferedReader.readLine().split(";");
                }
            }
        }catch (IOException e){
            Log.v("MainActivity", e.getMessage());
        }

        return dadosCarregados;
    }
}
