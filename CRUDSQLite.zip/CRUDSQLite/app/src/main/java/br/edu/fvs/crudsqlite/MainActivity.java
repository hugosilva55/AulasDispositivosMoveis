package br.edu.fvs.crudsqlite;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import br.edu.fvs.crudsqlite.usuario.Usuario;
import br.edu.fvs.crudsqlite.usuario.UsuarioDAO;

public class MainActivity extends AppCompatActivity {

    Button botaoEntrar;
    Button botaoSair;
    UsuarioDAO usuarioDAO;
    TextView usuario;
    TextView senha;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usuario = findViewById(R.id.Usuario);
        senha = findViewById(R.id.Senha);

        usuarioDAO = new UsuarioDAO(openOrCreateDatabase(usuarioDAO.NOME_BANCO, MODE_PRIVATE, null));

        botaoEntrar = findViewById(R.id.btEntrar);
        botaoSair = findViewById(R.id.btLogoff);

        botaoEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (usuarioDAO.autenticarUsuario(usuario.getText().toString(), senha.getText().toString())) {
                    Intent intent = new Intent(MainActivity.this, MenuPrincipal.class);
                    intent.putExtra("usuario", usuario.getText().toString());
                    startActivity(intent);
                }
            }
        });

        botaoSair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
            }
        });
    }
}
